
package Run;

import Funciones.Reserva;

public class Main {
    public static void main(String[] args) {
        Reserva canchas = new Reserva();
        canchas.crearLista();
        canchas.actualizarLista();
        System.out.println("");
        canchas.mostrarDisponibles();
    }
}
