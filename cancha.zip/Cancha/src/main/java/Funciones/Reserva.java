
package Funciones;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Reserva {
    private LocalDateTime aDateTime;    
    ArrayList<Cancha> listacanchas = new ArrayList<>();
    Scanner sc = new Scanner(System.in);
    public ArrayList<Cancha> crearLista(){
        listacanchas.add(new Cancha("futbol5",true,1));
        listacanchas.add(new Cancha("futbol5",true,2));
        listacanchas.add(new Cancha("futbol8",true,3));
        listacanchas.add(new Cancha("futbol8",true,4));
        return listacanchas;
    }
    public void mostrarDisponibles(){
        List<Cancha> canchasDispo = listacanchas.stream().filter(p->p.getDisponible().equals(true)).collect(Collectors.toList());
        canchasDispo.stream().forEach(System.out::println);
    }
    public void actualizarLista(){
        mostrarDisponibles();
        System.out.print("Digite el número de la cancha a reservar: ");
        int numero = sc.nextInt();
        listacanchas.stream().filter(p->p.getNumero()==numero).findFirst().get().setDisponible(false);
        Cancha c = listacanchas.stream().filter(p->p.getNumero()==numero).findFirst().get();
        System.out.println("La cancha " + c.getTipo() + " número " + c.getNumero() + " ha sido reservada ");
    }
    
    
}
