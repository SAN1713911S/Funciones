
package Funciones;

public class Cancha {

    private String tipo;
    private Boolean disponible;
    private int numero;

    public Cancha(String tipo, Boolean disponible, int numero) {
        this.tipo = tipo;
        this.disponible = disponible;
        this.numero = numero;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Boolean getDisponible() {
        return disponible;
    }

    public void setDisponible(Boolean disponible) {
        this.disponible = disponible;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }
    @Override
    public String toString() {
        return "Cancha #" + numero + ", " + tipo + ", disponible:" + disponible;
    }
}
